# 2023-12-08
# 4я стадия - генерация слоев почвенного климата и оценки их качества

# работчая директория
setwd('/media/carabus/Enterprise/EW_SDM/predictors/meteo/')

# необходимые библиотеки
library(DBI)
library(sf)
library(geodata)
library(ggplot2)
library(raster)
library(fields)

# база данных
connection <- dbConnect(RSQLite::SQLite(), "databases/soil_climate_temperature.sqlite")

# выбираем среднемесячные температуры
dbListTables(connection) # список таблиц в базе
dbListFields(connection,'soil_temperature_month') # список полей в таблице

mType = 'p' # вытяжные термометры

# сводные данные по вытяжным термометрам 
# сводная таблица по грубинам: число станций, общий объем наблюдений, самый ранний и поздний год
select = paste0('SELECT depth, count(t), min(year), max(year), ',
                'count(DISTINCT year), count(DISTINCT station_code) ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' ',
                'GROUP BY depth;')
result = dbGetQuery(connection, select)

# выбрали слои 20 (264 метеостанции), 40 (262) и 80 (264) см
# также наиболее полно представлены: 120 (205), 160 (259), 240 (187) и 320 (244) см

# сводная таблица по годам: сколько глубин отслеживали, минимальная и максимальная глубина
# число метеостанций и общее число наблюдений
select = paste0('SELECT year, count(DISTINCT depth), count(t), min(depth), ',
                ' max(depth), count(DISTINCT station_code) ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' ',
                'GROUP BY year;')
result = dbGetQuery(connection, select)

# три глубины: 20, 40, 80 см - то же самое, что и в предыдущем запросе
select = paste0('SELECT year, count(DISTINCT depth), count(t), min(depth), ',
                ' max(depth), count(DISTINCT station_code) ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' AND depth IN (20,40,80) ',
                'GROUP BY year;')
result = dbGetQuery(connection, select)

aoi = st_read('../../navigation/Russia_European_albers.shp')
plot(st_geometry(aoi))

station_list = read.csv('weather_stations/stations_vniigmi-mcd.csv')
nrow(station_list) # 1127 записей
head(station_list)

country = gadm('RU', path = '../../navigation/', level = 0)
ruBorder = st_as_sf(country)

# схема со всеми метеостанциями
plot(st_geometry(ruBorder), xlim = c(25,180),
     ylim = c(min(station_list$latitude), max(station_list$latitude)))

stations = st_as_sf(station_list, coords = c("longitude", "latitude"))
plot(st_geometry(stations), pch = 16, col = 'blue', cex = 0.6, add = T)
class(stations)

aoi_dd = st_transform(aoi, st_crs('EPSG:4326'))
plot(aoi_dd, add = T, lwd = 1.5, border = 'green')

aoiBuf128 = st_buffer(aoi,128000) # буфер 128 км
aoiBuf256 = st_buffer(aoi,256000) # буфер 256 км
plot(st_geometry(aoiBuf256), col = 'yellow')
plot(st_geometry(aoiBuf128), add = T, col = 'orange')
plot(st_geometry(aoi), add = T, col = 'green')

# слои в систему координат WGS84
aoiBuf128_dd = st_transform(aoiBuf128, st_crs('EPSG:4326')) 
aoiBuf256_dd = st_transform(aoiBuf256, st_crs('EPSG:4326'))

st_crs(stations) = st_crs('EPSG:4326') # десятичные градусы WGS84
st_crs(stations) = st_crs(aoi_dd)

ggplot() + 
  geom_sf(data = aoi_dd) +
  geom_sf(data = stations)

stAoi = st_filter(stations, aoi_dd) # 376 метеостанций в зоне интереса  
stAoi128 = st_filter(stations, aoiBuf128_dd) # 449 метеостанций с буффером 128 км
stAoi256 = st_filter(stations, aoiBuf256_dd) # 489 метеостанций с буффером 256 км


# составляем список метеостанций: число среднимесячных значений по глубинам 20, 40 и 80
select = paste0('SELECT station_code, count(t), min(year), max(year) ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' AND depth IN (20,40,80) ',
                'GROUP BY station_code;')
stDepth248List = dbGetQuery(connection, select)


# среднегодовая многолетняя температура почвы на глубине 20 см               
select = paste0('SELECT station_code code, round(avg(t),3) mean_t ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' AND depth = 20 ',
                'GROUP BY station_code;')
depth20 = dbGetQuery(connection, select)
nrow(depth20) # 264 метеостанций

# среднегодовая многолетняя температура почвы на глубине 40 см
select = paste0('SELECT station_code code, round(avg(t),3) mean_t ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' AND depth = 40 ',
                'GROUP BY station_code;')
depth40 = dbGetQuery(connection, select)
nrow(depth40) # 262 метеостанций

# среднегодовая многолетняя температура почвы на глубине 80 см
select = paste0('SELECT station_code code, round(avg(t),3) mean_t ',
                'FROM soil_temperature_month ',
                'WHERE measure_type = \'',mType,'\' AND depth = 80 ',
                'GROUP BY station_code;')
depth80 = dbGetQuery(connection, select)
nrow(depth80) # 262 метеостанций


# все метеостанции с данными по нужным глубинам
stDepth248List$station_code

# все метеостанции в зоне интереса с буфером 256 км
stAoi256$code

# 98 метеостанций
selectList = intersect(stDepth248List$station_code, stAoi256$code)

soilStations = stations[stations$code %in% selectList, ]
plot(st_geometry(soilStations), pch = 16, col = 'blue', cex = 2)
plot(st_geometry(aoiBuf256_dd), add = T)
#plot(st_geometry(stations), col = 'red', pch = 16, cex = 0.7, add = T)
plot(st_geometry(aoi_dd), add = T)

depth20aoi = merge(soilStations, depth20, by = 'code') 
depth40aoi = merge(soilStations, depth40, by = 'code')
depth80aoi = merge(soilStations, depth80, by = 'code')

depth20aoi$mean_t

plot(st_geometry(depth20aoi))

ggplot() +
  geom_sf(data = depth20aoi, aes(colour = mean_t))


blankRaster = raster(extent(aoiBuf256_dd), resolution = 0.1)

# интерполяция и заполнение растра
soil20 = rasterize(depth20aoi, blankRaster, 'mean_t')
xy = data.frame(xyFromCell(soil20, 1: ncell(soil20)))
v <- getValues(soil20)
tps <- Tps(xy, v)
soil20raster = interpolate(soil20, tps)
soil20rasterm = crop(mask(soil20raster, aoi_dd),extent(aoi_dd))

soil40 = rasterize(depth40aoi, blankRaster, 'mean_t')
xy = data.frame(xyFromCell(soil40, 1: ncell(soil40)))
v <- getValues(soil40)
tps <- Tps(xy, v)
soil40raster = interpolate(soil40, tps)
soil40rasterm = crop(mask(soil40raster, aoi_dd),extent(aoi_dd))

soil80 = rasterize(depth40aoi, blankRaster, 'mean_t')
xy = data.frame(xyFromCell(soil80, 1: ncell(soil80)))
v <- getValues(soil80)
tps <- Tps(xy, v)
soil80raster = interpolate(soil80, tps)
soil80rasterm = crop(mask(soil80raster, aoi_dd),extent(aoi_dd))


colfunc  <- colorRampPalette(c('blue','cyan','green','yellow'))

plot(soil20rasterm, col = colfunc(32), main = 'Mean temperature at 20 cm depth')
plot(st_geometry(soilStations), pch = 16, col = 'blue', add = T, cex = 0.7)

plot(soilT20y, col = colfunc(32), main = 'Mean temperature at 20 cm depth')
plot(st_geometry(soilStations), pch = 16, col = 'blue', add = T, cex = 0.7)

plot(soilT40y, col = colfunc(32), main = 'Mean temperature at 40 cm depth')

plot(soilT80y, col = colfunc(32), main = 'Mean temperature at 80 cm depth')

soilT20y = soilT(depth20aoi, 0.05)
writeRaster(soilT20y, 'rasters/soilT20.tiff', overwrite = TRUE)

soilT40y = soilT(depth40aoi, 0.05)
writeRaster(soilT40y, 'rasters/soilT40.tiff', overwrite = TRUE)

soilT80y = soilT(depth80aoi, 0.05)
writeRaster(soilT80y, 'rasters/soilT80.tiff', overwrite = TRUE)

par(mfrow = c(1,3))
plot(soilT20y,  col = colfunc(32))
plot(soilT40y,  col = colfunc(32))
plot(soilT80y,  col = colfunc(32))


extent(aoi_dd)

# по месяцам
byMonth = paste0('SELECT station_code code, round(avg(CASE month WHEN 1 THEN t END),2) Jan, ',
                 'round(avg(CASE month WHEN 2 THEN t END),2) Feb,  round(avg(CASE month WHEN 3 THEN t END),2) Mar, ',
                 'round(avg(CASE month WHEN 4 THEN t END),2) Apr,  round(avg(CASE month WHEN 5 THEN t END),2) May, ', 
                 'round(avg(CASE month WHEN 6 THEN t END),2) Jun,  round(avg(CASE month WHEN 7 THEN t END),2) Jul, ', 
                 'round(avg(CASE month WHEN 8 THEN t END),2) Aug,  round(avg(CASE month WHEN 9 THEN t END),2) Sep, ',
                 'round(avg(CASE month WHEN 10 THEN t END),2) Oct, round(avg(CASE month WHEN 11 THEN t END),2) Nov, ',
                 'round(avg(CASE month WHEN 12 THEN t END),2) Dec FROM soil_temperature_month ')

# среднемесячная многолетняя температура на глубине 20 см
select = paste0(byMonth,' WHERE measure_type = \'',mType,'\' AND depth = 20 ',
                'AND quality IN (1,2,3) GROUP BY station_code;')
depth20m = dbGetQuery(connection, select)

# среднемесячная многолетняя температура на глубине 40 см
select = paste0(byMonth,' WHERE measure_type = \'',mType,'\' AND depth = 40 ',
                'AND quality IN (1,2,3) GROUP BY station_code;')
depth40m = dbGetQuery(connection, select)

# среднемесячная многолетняя температура на глубине 80 см
select = paste0(byMonth,' WHERE measure_type = \'',mType,'\' AND depth = 80 ',
                'AND quality IN (1,2,3) GROUP BY station_code;')
depth80m = dbGetQuery(connection, select)

write.csv(depth20m,'depth20mRaw.csv')
write.csv(depth40m,'depth40mRaw.csv')
write.csv(depth80m,'depth80mRaw.csv')


# процедура для формирования растровых слоёв
soilT <- function(soilTable, resl = 0.1) {
  # resl = 0.05
  # soilTable = snowMonth
  blankRaster = raster(extent(aoiBuf256_dd), resolution = resl) # пустой растр нужного размера
  soilLayer = rasterize(soilTable, blankRaster, 'mean_depth') # "точечный" растр 
  # далее интерполяция
  xy = data.frame(xyFromCell(soilLayer, 1 : ncell(soilLayer))) # набор координат всех элементов растра
  v <- getValues(soilLayer) # значения для всех элементов растра, большая часть будет NA
  tps <- Tps(xy, v) # строим модель интерполяции
  soilLayerInterpolate = interpolate(soilLayer, tps) # собственно интерполяция "точечного" растра
  soilLayerComplete = crop(mask(soilLayerInterpolate, aoi_dd),extent(aoi_dd))
  crs(soilLayerComplete) = 'EPSG:4326'
  return(soilLayerComplete)
}

month = c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')

depth20mSel = depth20m[depth20m$code %in% selectList,]
input20 = merge(depth20mSel, stAoi256, by = 'code')
input20s = st_as_sf(input20)
plot(st_geometry(input20s))

depth40mSel = depth40m[depth40m$code %in% selectList,]
input40 = merge(depth40mSel, stAoi256, by = 'code')
input40s = st_as_sf(input40)
plot(st_geometry(input40s))

depth80mSel = depth80m[depth80m$code %in% selectList,]
input80 = merge(depth80mSel, stAoi256, by = 'code')
input80s = st_as_sf(input80)
plot(st_geometry(input80s))

# экспортируем помесячно, глубина 20 см
for (i in 2:13) {
  input20sm = input20s[,c('code','geometry',month[i-1])]
  colnames(input20sm)[3] = 'mean_t'
  monthT = soilT(input20sm,0.05)
  plot(monthT, col = colfunc(32))
  writeRaster(monthT, paste0('rasters/soilT20_0',(i-1),'.tiff'), overwrite = TRUE)
}

# экспортируем помесячно, глубина 40 см
for (i in 2:13) {
  input40sm = input40s[,c('code','geometry',month[i-1])]
  colnames(input40sm)[3] = 'mean_t'
  monthT = soilT(input40sm,0.05)
  plot(monthT, col = colfunc(32))
  writeRaster(monthT, paste0('rasters/soilT40_0',(i-1),'.tiff'), overwrite = TRUE)
}

# экспортируем помесячно, глубина 80 см
for (i in 2:13) {
  input80sm = input80s[,c('code','geometry',month[i-1])]
  colnames(input80sm)[3] = 'mean_t'
  monthT = soilT(input80sm,0.05)
  plot(monthT, col = colfunc(32))
  writeRaster(monthT, paste0('rasters/soil/soilT80_0',(i-1),'.tiff'), overwrite = TRUE)
}



# слои со снежным покровом
# база данных
connection <- dbConnect(RSQLite::SQLite(), "databases/soil_climate_snow.sqlite")

# выбираем среднемесячные температуры
dbListTables(connection) # список таблиц в базе
dbListFields(connection,'snow_cover_monthly') # список полей в таблице

select = paste0('SELECT station_code code, round(avg(depth),1) mean_depth, count(depth) n_values,', 
                'max(depth) max_depth, count(DISTINCT year) n_years ',
                'FROM snow_cover_monthly ',
                'GROUP BY station_code;')
snow = dbGetQuery(connection, select)
head(snow)

selectList = intersect(snow$code, stAoi256$code)
length(selectList) # всего 216 станций

snowSel = snow[snow$code %in% selectList,]
inputSnow = st_as_sf(merge(snowSel, stAoi256, by = 'code'))
plot(st_geometry(aoi_dd))
plot(st_geometry(inputSnow), add = T)

snowCover = soilT(inputSnow, 0.05)
colfuncws <- colorRampPalette(c('aliceblue','cyan','blue'))
plot(snowCover, col = colfuncws(32))
writeRaster(snowCover, 'rasters/snowCover.tiff')

select = paste0('SELECT station_code code, round(avg(CASE month WHEN 1 THEN depth END),2) Jan, ',
                 'round(avg(CASE month WHEN 2 THEN depth END),2) Feb, round(avg(CASE month WHEN 3 THEN depth END),2) Mar, ',
                 'round(avg(CASE month WHEN 4 THEN depth END),2) Apr, round(avg(CASE month WHEN 5 THEN depth END),2) May, ', 
                 'round(avg(CASE month WHEN 6 THEN depth END),2) Jun, round(avg(CASE month WHEN 7 THEN depth END),2) Jul, ', 
                 'round(avg(CASE month WHEN 8 THEN depth END),2) Aug, round(avg(CASE month WHEN 9 THEN depth END),2) Sep, ',
                 'round(avg(CASE month WHEN 10 THEN depth END),2) Oct, round(avg(CASE month WHEN 11 THEN depth END),2) Nov, ',
                 'round(avg(CASE month WHEN 12 THEN depth END),2) Dec FROM snow_cover_monthly GROUP BY station_code;')
snowMonth = dbGetQuery(connection, select)
write.csv(snowMonth, 'snowMonthRaw.csv')
snowMonth = st_as_sf(merge(snowMonth, stAoi256, by = 'code'))
names(snowMonth)

for (i in 2:13) {
  # i = 2
  snowMonthN = snowMonth[,c('code','geometry',month[i-1])]
  colnames(snowMonthN)[3] = 'mean_depth'
  snowMonthR = soilT(snowMonthN,0.05)
  # plot(monthT, col = colfunc(32))
  writeRaster(snowMonthR, paste0('rasters/snow_0',(i-1),'.tiff'), overwrite = TRUE)
}